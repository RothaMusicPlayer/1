const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const POS_PORT = process.env.POS_PORT || 3000;
const CONTROL_PORT = process.env.CONTROL_PORT || 4000;

const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');
const POS_PUBLIC = path.join(__dirname, 'client-pos');
const CONTROL_PUBLIC = path.join(__dirname, 'control-admin');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DEFAULT_STORE = {
  settings: {
    shopName: "Coffee & Drinks",
    receiptFooter: "សូមអរគុណ! Thank you!",
    qrEnabled: true,
    qrImageDataUrl: "",
    currency: "USD",
    khrRate: 4000,
    tableCount: 5,
    enableTakeaway: true,
    lockMenuAndData: false,
    darkMode: false,
    lang: "km",
    priceOverrides: {},
    disabledItems: {}
  },
  cartItems: [],
  orders: [],
  dailyChartLog: {}
};

function readStore() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      fs.writeFileSync(DB_FILE, JSON.stringify(DEFAULT_STORE, null, 2), 'utf8');
      return JSON.parse(JSON.stringify(DEFAULT_STORE));
    }
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      settings: Object.assign({}, DEFAULT_STORE.settings, parsed.settings || {}),
      cartItems: Array.isArray(parsed.cartItems) ? parsed.cartItems : [],
      orders: Array.isArray(parsed.orders) ? parsed.orders : [],
      dailyChartLog: parsed.dailyChartLog && typeof parsed.dailyChartLog === 'object' ? parsed.dailyChartLog : {}
    };
  } catch (err) {
    console.error('Error reading store.json:', err);
    return JSON.parse(JSON.stringify(DEFAULT_STORE));
  }
}

function writeStore(nextStore) {
  fs.writeFileSync(DB_FILE, JSON.stringify(nextStore, null, 2), 'utf8');
  broadcastUpdate(nextStore);
}

// Connected SSE clients (both POS and Control clients stay synced in real time)
const sseClients = new Set();

function broadcastUpdate(storeData) {
  const payload = `data: ${JSON.stringify({ type: 'SYNC_STATE', store: storeData, updatedAt: Date.now() })}\n\n`;
  for (const res of sseClients) {
    try {
      res.write(payload);
    } catch {
      sseClients.delete(res);
    }
  }
}

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

function sendJson(res, statusCode, obj) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(obj));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
      if (body.length > 10 * 1024 * 1024) {
        reject(new Error('Payload too large'));
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try {
        resolve(JSON.parse(body));
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

function serveStaticFile(res, rootDir, reqPathname) {
  let cleanPath = reqPathname === '/' ? '/index.html' : reqPathname;
  // Shared recipes data file accessible by both POS and Control
  if (cleanPath === '/shared/recipes.js') {
    const sharedFile = path.join(__dirname, 'shared', 'recipes.js');
    if (fs.existsSync(sharedFile)) {
      res.writeHead(200, { 'Content-Type': 'application/javascript; charset=utf-8' });
      return fs.createReadStream(sharedFile).pipe(res);
    }
  }

  const safePath = path.normalize(cleanPath).replace(/^(\.\.[\/\\])+/, '');
  const filePath = path.join(rootDir, safePath);

  if (!filePath.startsWith(rootDir) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    return res.end('404 Not Found');
  }

  const ext = path.extname(filePath).toLowerCase();
  res.writeHead(200, { 'Content-Type': MIME_TYPES[ext] || 'application/octet-stream' });
  fs.createReadStream(filePath).pipe(res);
}

async function handleApiRequest(req, res, pathname, isControlServer) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    return res.end();
  }

  // Real-time SSE stream
  if (req.method === 'GET' && pathname === '/api/events') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write(`data: ${JSON.stringify({ type: 'CONNECTED', store: readStore() })}\n\n`);
    sseClients.add(res);
    req.on('close', () => sseClients.delete(res));
    return;
  }

  // GET full state (settings + orders + cart + chart)
  if (req.method === 'GET' && pathname === '/api/state') {
    return sendJson(res, 200, { ok: true, store: readStore() });
  }

  // GET settings only
  if (req.method === 'GET' && pathname === '/api/settings') {
    return sendJson(res, 200, { ok: true, settings: readStore().settings });
  }

  // UPDATE settings (Control Server endpoint — also accessible if authenticated)
  if (req.method === 'PUT' && pathname === '/api/settings') {
    if (!isControlServer) {
      return sendJson(res, 403, { ok: false, error: 'Settings can only be modified from Control Server (port ' + CONTROL_PORT + ')' });
    }
    try {
      const body = await parseBody(req);
      const store = readStore();
      store.settings = Object.assign({}, store.settings, body);
      writeStore(store);
      return sendJson(res, 200, { ok: true, settings: store.settings });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  // SYNC cart / orders / chart from POS or Control Server
  if (req.method === 'POST' && pathname === '/api/sync') {
    try {
      const body = await parseBody(req);
      const store = readStore();
      if (Array.isArray(body.cartItems)) store.cartItems = body.cartItems;
      if (Array.isArray(body.orders)) store.orders = body.orders;
      if (body.dailyChartLog && typeof body.dailyChartLog === 'object') store.dailyChartLog = body.dailyChartLog;
      writeStore(store);
      return sendJson(res, 200, { ok: true, store });
    } catch (err) {
      return sendJson(res, 400, { ok: false, error: err.message });
    }
  }

  // RESET all data (Control Server only)
  if (req.method === 'POST' && pathname === '/api/reset') {
    if (!isControlServer) {
      return sendJson(res, 403, { ok: false, error: 'Reset is restricted to Control Server' });
    }
    const fresh = JSON.parse(JSON.stringify(DEFAULT_STORE));
    writeStore(fresh);
    return sendJson(res, 200, { ok: true, store: fresh });
  }

  return sendJson(res, 404, { ok: false, error: 'API route not found' });
}

// 1. POS Server (Customer & Barista Ordering Interface — Settings moved out!)
const posServer = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  if (parsedUrl.pathname.startsWith('/api/')) {
    return handleApiRequest(req, res, parsedUrl.pathname, false);
  }
  serveStaticFile(res, POS_PUBLIC, parsedUrl.pathname);
});

// 2. Control Server (Admin Settings & Full Store Control)
const controlServer = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  if (parsedUrl.pathname.startsWith('/api/')) {
    return handleApiRequest(req, res, parsedUrl.pathname, true);
  }
  serveStaticFile(res, CONTROL_PUBLIC, parsedUrl.pathname);
});

posServer.listen(POS_PORT, () => {
  console.log(`☕ POS Client Server running at:     http://localhost:${POS_PORT}`);
});

controlServer.listen(CONTROL_PORT, () => {
  console.log(`🎛️  Control Admin Server running at: http://localhost:${CONTROL_PORT}`);
});
