# Coffee & Drinks — Split POS & Control Admin Server

ប្រព័ន្ធត្រូវបានបំបែកជា Files ដាច់ដោយឡែក និងមាន Server ចំនួន ២ ដំណើរការព្រមគ្នាដោយភ្ជាប់ទិន្នន័យ Real-Time (SSE):

## រចនាសម្ព័ន្ធ Folder (Project Structure)
```text
coffee-pos-system/
├── package.json
├── server.js                 # Dual-Port Server (POS: 3000 & Control Admin: 4000) + Real-Time Sync API
├── data/
│   └── store.json            # មូលដ្ឋានទិន្នន័យកណ្តាល (Settings, Orders, Cart, Daily Chart)
├── shared/
│   └── recipes.js            # ទិន្នន័យម៉ឺនុយ និងរូបមន្តរួម
├── client-pos/               # កម្មវិធីលក់ POS (Port 3000 - គ្មានប៊ូតុង Settings ទេ)
│   ├── index.html
│   ├── css/pos.css
│   └── js/pos-app.js
└── control-admin/            # កម្មវិធីគ្រប់គ្រង Settings ទាំងអស់ (Port 4000)
    ├── index.html
    ├── css/control.css
    └── js/control-app.js
```

## របៀបដំណើរការ (How to Run)
1. ត្រូវប្រាកដថាមាន **Node.js** ដំឡើងរួចនៅលើម៉ាស៊ីន (មិនបាច់ run `npm install` ទេ ព្រោះប្រើ Built-in Node.js modules សុទ្ធ)។
2. បើក Terminal ក្នុង Folder `coffee-pos-system` រួចវាយ៖
   ```bash
   node server.js
   ```
3. បើក Browser៖
   - **POS Client (សម្រាប់កុម្ម៉ង់ & គិតលុយ):** `http://localhost:3000`
   - **Control Server (សម្រាប់គ្រប់គ្រង Settings ទាំងអស់):** `http://localhost:4000`
